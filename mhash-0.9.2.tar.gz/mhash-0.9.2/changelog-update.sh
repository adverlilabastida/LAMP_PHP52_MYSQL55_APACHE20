rcs2log -u "nikos	Nikos Mavroyanopoulos	nmav@hellug.gr" -u "sascha	Sascha Schumann	sascha@schumann.cx"  > ChangeLog
